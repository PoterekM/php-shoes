-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Jul 22, 2017 at 01:39 AM
-- Server version: 5.5.42-log
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoe_store_test`
--
CREATE DATABASE IF NOT EXISTS `shoe_store_test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `shoe_store_test`;

-- --------------------------------------------------------

--
-- Table structure for table `shoes`
--

CREATE TABLE `shoes` (
  `brand` varchar(30) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `shoes_stores`
--

CREATE TABLE `shoes_stores` (
  `id` bigint(20) unsigned NOT NULL,
  `shoe_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shoes_stores`
--

INSERT INTO `shoes_stores` (`id`, `shoe_id`, `store_id`) VALUES
(1, 141, 80),
(2, 141, 81),
(3, 152, 91),
(4, 153, 92),
(5, 153, 93),
(6, 164, 103),
(7, 165, 104),
(8, 165, 105),
(9, 176, 115),
(10, 177, 116),
(11, 177, 117),
(12, 188, 127),
(13, 189, 128),
(14, 189, 129),
(15, 200, 139),
(16, 201, 140),
(17, 201, 141),
(18, 235, 174),
(19, 236, 175),
(20, 236, 176),
(21, 271, 210),
(22, 272, 211),
(23, 272, 212),
(24, 283, 222),
(25, 284, 223),
(26, 284, 224),
(27, 295, 234),
(28, 296, 235),
(29, 296, 236),
(30, 307, 246),
(31, 308, 247),
(32, 308, 248),
(33, 319, 258),
(34, 320, 259),
(35, 320, 260),
(36, 488, 421),
(37, 489, 422),
(38, 490, 422),
(39, 501, 432),
(40, 502, 433),
(41, 503, 433),
(42, 514, 443),
(43, 515, 444),
(44, 516, 444),
(45, 527, 454),
(46, 528, 455),
(47, 529, 455),
(48, 542, 468),
(49, 543, 469),
(50, 544, 469),
(51, 557, 482),
(52, 558, 483),
(53, 559, 483),
(54, 570, 484),
(55, 571, 485),
(56, 571, 486),
(57, 572, 496),
(58, 573, 497),
(59, 574, 497),
(60, 585, 498),
(61, 586, 499),
(62, 586, 500),
(63, 587, 510),
(64, 588, 511),
(65, 589, 511),
(66, 600, 512),
(67, 601, 513),
(68, 601, 514),
(69, 602, 524),
(70, 603, 525),
(71, 604, 525),
(72, 615, 526),
(73, 616, 527),
(74, 616, 528),
(75, 617, 538),
(76, 618, 539),
(77, 619, 539),
(78, 630, 540),
(79, 631, 541),
(80, 631, 542),
(81, 632, 552),
(82, 633, 553),
(83, 634, 553),
(84, 645, 554),
(85, 646, 555),
(86, 646, 556),
(87, 647, 566),
(88, 648, 567),
(89, 649, 567),
(90, 660, 568),
(91, 661, 569),
(92, 661, 570),
(93, 662, 580),
(94, 663, 581),
(95, 664, 581),
(96, 675, 582),
(97, 676, 583),
(98, 676, 584),
(99, 677, 594),
(100, 678, 595),
(101, 679, 595),
(102, 692, 608),
(103, 693, 609),
(104, 694, 609),
(105, 705, 610),
(106, 706, 611),
(107, 706, 612),
(108, 707, 622),
(109, 708, 623),
(110, 709, 623),
(111, 720, 624),
(112, 721, 625),
(113, 721, 626),
(114, 722, 636),
(115, 723, 637),
(116, 724, 637),
(117, 735, 638),
(118, 736, 639),
(119, 736, 640),
(120, 737, 650),
(121, 738, 651),
(122, 739, 651),
(123, 750, 652),
(124, 751, 653),
(125, 751, 654),
(126, 752, 664),
(127, 753, 665),
(128, 754, 665),
(129, 765, 666),
(130, 766, 667),
(131, 766, 668),
(132, 767, 678),
(133, 768, 679),
(134, 769, 679),
(135, 780, 680),
(136, 781, 681),
(137, 781, 682),
(138, 782, 692),
(139, 783, 693),
(140, 784, 693),
(141, 795, 694),
(142, 796, 695),
(143, 796, 696),
(144, 797, 706),
(145, 798, 707),
(146, 799, 707),
(147, 810, 708),
(148, 811, 709),
(149, 811, 710),
(150, 812, 720),
(151, 813, 721),
(152, 814, 721),
(153, 825, 722),
(154, 826, 723),
(155, 826, 724),
(156, 827, 734),
(157, 828, 735),
(158, 829, 735),
(159, 840, 736),
(160, 841, 737),
(161, 841, 738),
(162, 842, 748),
(163, 843, 749),
(164, 844, 749),
(165, 11, 1),
(166, 12, 2),
(167, 12, 3),
(168, 13, 13),
(169, 14, 14),
(170, 15, 14),
(171, 26, 15),
(172, 27, 16),
(173, 27, 17),
(174, 28, 27),
(175, 29, 28),
(176, 30, 28);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `store` varchar(30) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `shoes`
--
ALTER TABLE `shoes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `shoes_stores`
--
ALTER TABLE `shoes_stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `shoes`
--
ALTER TABLE `shoes`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `shoes_stores`
--
ALTER TABLE `shoes_stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=177;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
